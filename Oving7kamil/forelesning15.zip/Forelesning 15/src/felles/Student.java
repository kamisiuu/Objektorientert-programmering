package felles;

public class Student implements Comparable<Student>{
	private int studId;
	private String fNavn;
	private String eNavn;
	private String adr;
	private int pnr;
	private String pSted;
	
	// konstrukt�r
	public Student(int id, String fNavn, String eNavn, String adr, int pnr,
			String pSted) {
		this.studId = id;
		this.fNavn = fNavn;
		this.eNavn = eNavn;
		this.adr = adr;
		this.pnr = pnr;
		this.pSted = pSted;
	}
	
	// implementert metode fra Comparable
	@Override
	public int compareTo(Student o) {
		// sjekker dette objektet er MINDRE enn objektet vi f�r inn sin studId
		if(studId < o.studId){
			return -1;
		}
		
		// sjekker dette objektet er ST�RRE enn objektet vi f�r inn sin studId
		else if(studId > o.studId){
			return 1;
		}
		
		// om den hverken er st�rre eller mindre m� den implisitt v�re LIK
		return 0;
	}
	
	// tostring slik at vi f�r ut noe annet enn giberish
	@Override
	public String toString(){
		return studId + " " + fNavn + " " + eNavn;
	}

	// get og set
	public int getStudId() {
		return studId;
	}

	public void setId(int id) {
		this.studId = id;
	}

	public String getfNavn() {
		return fNavn;
	}

	public void setfNavn(String fNavn) {
		this.fNavn = fNavn;
	}

	public String geteNavn() {
		return eNavn;
	}

	public void seteNavn(String eNavn) {
		this.eNavn = eNavn;
	}

	public String getAdr() {
		return adr;
	}

	public void setAdr(String adr) {
		this.adr = adr;
	}

	public int getPnr() {
		return pnr;
	}

	public void setPnr(int pnr) {
		this.pnr = pnr;
	}

	public String getpSted() {
		return pSted;
	}

	public void setpSted(String pSted) {
		this.pSted = pSted;
	}
	
}
