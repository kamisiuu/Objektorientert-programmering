package naturalOrder;

import java.util.ArrayList;
import java.util.Collections;

import felles.Student;

public class NaturalMain {
	public static void main(String[] args){
		
		//**************** int ******************
		
		ArrayList<Integer> intListe = new ArrayList<>();
		intListe.add(3);
		intListe.add(1);
		intListe.add(31);
		intListe.add(17);
		
		// sorterer listen i naturlig orden (�kende)
		Collections.sort(intListe);
		
		// skriver ut resultatet av sorteringen
		System.out.println("Sortert tallListe:");
		for(int i : intListe){
			System.out.println(i);
		}
		System.out.println("");
		
		//************** String ****************
		ArrayList<String> navneListe = new ArrayList<>();
		navneListe.add("Per");
		navneListe.add("Ola");
		navneListe.add("Kari");
		navneListe.add("Anna");
		
		// sorterer listen i naturlig orden
		Collections.sort(navneListe);
		
		// skriver ut resultatet av sorteringen
		System.out.println("Sortert navneliste:");
		for(String navn: navneListe){
			System.out.println(navn);
		}
		
		//************** Student ***************
		ArrayList<Student> studentListe = new ArrayList<>();
		studentListe.add(new Student(101, "Per", "Bisseberg", "Parkveien 68", 1768, "Halden"));
		studentListe.add(new Student(35, "Anna", "Hagen", "L�kkebergveien 32", 1792, "Tistedal"));
		studentListe.add(new Student(267, "�se", "Bakken", "Stubben 3", 1617, "Fredrikstad"));
		
		// sorterer listen i naturlig orden
		Collections.sort(studentListe);
		
		// skriver ut resultatet av sorteringen ved � bruke en tostring() metode i Student 
		System.out.println("");
		for(Student stud : studentListe){
			System.out.println(stud);
		}	
	}
}
