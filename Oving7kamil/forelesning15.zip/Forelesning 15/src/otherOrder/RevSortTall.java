package otherOrder;

import java.util.Comparator;

public class RevSortTall implements Comparator<Integer> {

	@Override
	public int compare(Integer tall1, Integer tall2) {
		// sjekker om tall1 er st�rre enn tall2
		if(tall1 > tall2){
			return -1;
		}
		
		// sjekker om tall1 er mindre enn tall2
		if(tall1 < tall2){
			return 1;
		}
		
		// om like
		return 0;
	}

}
