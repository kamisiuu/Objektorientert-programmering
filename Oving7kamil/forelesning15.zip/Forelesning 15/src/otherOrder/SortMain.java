package otherOrder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import felles.Student;

public class SortMain {

	public static void main(String[] args) {
		// **************** int ******************

		ArrayList<Integer> intListe = new ArrayList<>();
		intListe.add(3);
		intListe.add(1);
		intListe.add(31);
		intListe.add(17);

		// oppretter objekt av Comparator
		RevSortTall revComparator = new RevSortTall();

		// sorterer listen synkende
		Collections.sort(intListe, revComparator);

		// skriver ut resultatet av sorteringen
		System.out.println("Sortert tallListe:");
		for (int i : intListe) {
			System.out.println(i);
		}
		System.out.println("");

		// ************** Student ***************
		ArrayList<Student> studentListe = new ArrayList<>();
		studentListe.add(new Student(101, "Per", "Bisseberg", "Parkveien 68",
				1768, "Halden"));
		studentListe.add(new Student(35, "Anna", "Hagen", "L�kkebergveien 32",
				1792, "Tistedal"));
		studentListe.add(new Student(267, "�se", "Bakken", "Stubben 3", 1617,
				"Fredrikstad"));


		// sorterer listen etter etternavn, vi m� da lage et objekt som implementerer Comparator
		Collections.sort(studentListe, new Comparator<Student>() {
			
			// implementerer compare metoden som er definert i interfacet
			@Override
			public int compare(Student stud1, Student stud2) {
				// vi henter etternavn for hver av disse studentobjektene
				String stud1Etternavn = stud1.geteNavn();
				String stud2Etternavn = stud2.geteNavn();
				
				/*
				 *  vi kunne gjort logikk her som returnerte 1, -1 og 0
				 *  men vi vet at String-klassen implementerer Comparable interfacet
				 *  dermed kan vi bruke strengenes compareTo(Object o) metode som da vil returnere
				 *  1, -1 og 0 automagisk
				 */
				
				return stud1Etternavn.compareTo(stud2Etternavn);
			}
		});

		// skriver ut resultatet av sorteringen ved � bruke en tostring() metode
		// i Student
		System.out.println("");
		for (Student stud : studentListe) {
			System.out.println(stud);
		}
	}

}
